<div class="container">
    <div class="col-lg-12" style="text-align:center; padding-top: 20px; padding-bottom: 20px;">
        <p> All rights reserved.</p>
    </div>
</div>
